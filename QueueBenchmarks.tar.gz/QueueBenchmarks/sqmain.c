//---------------------------------------------------------------
// File: sqmain.c
// Author: Poornima Nookala
// Date: February 24, 2017
//---------------------------------------------------------------
#define _GNU_SOURCE

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <pthread.h>
#include <sys/types.h>
#include <sched.h>
#include <ck_ring.h>
#include <inttypes.h>
#include "squeue.h"
#include "basicqueue.h"
#include <time.h>

struct entry {
	int tid;
	int value;
};

struct arg_struct {
	ck_ring_buffer_t *buf;
	ck_ring_t ring;
};

int r, size;
uint64_t s, e, e_a, d_a = 0;
struct timeval sTime, eTime;

typedef long unsigned int ticks;
#define NUM_THREADS 8
#define NUM_CPUS 1

ticks *enqueuetimestamp, *dequeuetimestamp;

//#ifdef VERBOSE
static int numEnqueue = 0;
static int numDequeue = 0;
//#endif

static ticks dequeue_ticks = 0, enqueue_ticks = 0;
static int CUR_NUM_THREADS = NUM_THREADS;

//An alternative way is to use rdtscp which will wait until all previous instructions have been executed before reading the counter; might be problematic on multi-core machines
static __inline__ ticks getticks_serial(void) {
	ticks tsc;
	__asm__ __volatile__(
			"rdtscp;"
			"shl $32, %%rdx;"
			"or %%rdx, %%rax"
			: "=a"(tsc)
			  :
			  : "%rcx", "%rdx");

	return tsc;
}

//get number of ticks, could be problematic on modern CPUs with out of order execution
static __inline__ ticks getticks(void) {
	ticks tsc;
	__asm__ __volatile__(
			"rdtsc;"
			"shl $32, %%rdx;"
			"or %%rdx, %%rax"
			: "=a"(tsc)
			  :
			  : "%rcx", "%rdx");

	return tsc;
}

void *worker_handler(void * in) {
	int my_cpu = (int) (long) in;

	cpu_set_t set;

	CPU_ZERO(&set);
	CPU_SET(my_cpu % NUM_CPUS, &set);

	pthread_setaffinity_np(pthread_self(), sizeof(set), &set);

	ticks start_tick, end_tick;

	int NUM_SAMPLES_PER_THREAD = NUM_SAMPLES / CUR_NUM_THREADS;
	//start_tick = getticks();
	for (int i = 0; i < NUM_SAMPLES_PER_THREAD; i++)
	{
		start_tick = getticks();
		Dequeue();
		end_tick = getticks();

		dequeuetimestamp[numDequeue] = (end_tick-start_tick);

//#ifdef VERBOSE
		__sync_fetch_and_add(&numDequeue,1);
//#endif
#ifdef VERBOSE
		printf("Dequeue time: %ld\n", (end_tick-start_tick));
#endif

	}

	return 0;

}

void *enqueue_handler(void * in)
{
	int my_cpu = (int) (long) in;

	cpu_set_t set;

	CPU_ZERO(&set);
	CPU_SET(my_cpu % NUM_CPUS, &set);

	pthread_setaffinity_np(pthread_self(), sizeof(set), &set);

	ticks start_tick = (ticks)0;
	ticks end_tick = (ticks)0;

	int NUM_SAMPLES_PER_THREAD = NUM_SAMPLES / CUR_NUM_THREADS;

	for (int i = 0; i < NUM_SAMPLES_PER_THREAD; i++)
	{
		start_tick = getticks();
		Enqueue((atom) (i+1));
		end_tick = getticks();
		enqueuetimestamp[numEnqueue] = (end_tick-start_tick);

//#ifdef VERBOSE
		__sync_fetch_and_add(&numEnqueue,1);
//#endif
#ifdef VERBOSE
	printf("Enqueue time: %ld\n", (end_tick-start_tick));
#endif
	}

	//__sync_add_and_fetch(&enqueue_ticks, (end_tick-start_tick));

	return 0;
}

void *ck_worker_handler(void *arguments) {
	struct arg_struct *args = (struct arg_struct *) arguments;
	struct entry entry;
	ck_ring_buffer_t *buf = args->buf;
	ck_ring_t ring = args->ring;
	s = getticks();
	ck_ring_dequeue_spmc(&ring, buf, &entry);
	e = getticks();
	d_a += (e - s);
	__sync_add_and_fetch(&dequeue_ticks, d_a);

	return 0;
}

void *basicworker_handler(void *_queue)
{
	ticks start_tick,end_tick;

	int NUM_SAMPLES_PER_THREAD = NUM_SAMPLES/NUM_THREADS;
	for (int i=0;i<NUM_SAMPLES_PER_THREAD;i++)
	{
		//gettimeofday(&sTime, NULL);
		//int startSeconds = sTime.tv_sec + ((double)sTime.tv_usec)/1000000.0;
		start_tick = getticks();
		BasicDequeue();
		end_tick = getticks();
		//gettimeofday(&eTime, NULL);
		//int endSeconds = eTime.tv_sec + ((double)eTime.tv_usec)/1000000.0;
		//__sync_add_and_fetch(&dequeue_time,(endSeconds-startSeconds));
		__sync_add_and_fetch(&dequeue_ticks,(end_tick-start_tick));
	}

	return 0;
}

void ResetCounters() {
	dequeue_ticks = 0;
	enqueue_ticks = 0;
//#ifdef VERBOSE
	numEnqueue = 0;
	numDequeue = 0;
//#endif
}

int main(int argc, char **argv) {
	int i;
	///////////////////////////// SQueue - Lock free queue - SECD /////////////////////////////////
	/*printf("Num threads - %d, Num Samples - %d, Num CPUs - %d \n", NUM_THREADS,
			NUM_SAMPLES, NUM_CPUS);
	printf("\nSQueue - Single Enqueue Concurrent Dequeue\n");
	printf("Type,Operation,NumSamples,CycleCount,NumThreads\n");
	for (k = 1; k <= NUM_THREADS; k = k * 2) {
		InitQueue();
		ResetCounters();
		CUR_NUM_THREADS = k;
		ticks start_tick, end_tick, diff_tick;
		pthread_t *worker_threads;
		worker_threads = (pthread_t *) malloc(
				sizeof(pthread_t) * CUR_NUM_THREADS);

		cpu_set_t set;

		CPU_ZERO(&set);
		CPU_SET(0, &set);

		pthread_setaffinity_np(pthread_self(), sizeof(set), &set);

#ifndef WAITFORENQUEUE
		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&worker_threads[i], NULL, worker_handler,
					(void*) (unsigned long) (i + 1));
#endif

		start_tick = getticks();
		for (i = 0; i < NUM_SAMPLES; i++) {
			Enqueue((atom) (i + 1));
#ifdef VERBOSE
			__sync_fetch_and_add(&numEnqueue,1);
#endif
		}
		end_tick = getticks();

#ifdef WAITFORENQUEUE
		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&worker_threads[i], NULL, worker_handler, (void*)(unsigned long)(i+1));
#endif
		diff_tick = end_tick - start_tick;

		for (i = 0; i < CUR_NUM_THREADS; i++)
					pthread_join(worker_threads[i], NULL);

#ifdef VERBOSE
		printf("Enqueue time: %ld\n", diff_tick/NUM_SAMPLES);
#endif

		printf("squeue_secd,enqueue,%d,%ld,%d\n", NUM_SAMPLES, diff_tick / NUM_SAMPLES,
				CUR_NUM_THREADS);

		printf("squeue_secd,dequeue,%d,%ld,%d\n", NUM_SAMPLES,
				dequeue_ticks / NUM_SAMPLES, CUR_NUM_THREADS);

#ifdef VERBOSE
		printf("Enqueue ops: %d\n", numEnqueue);
		printf("Dequeue ops: %d\n", numDequeue);
#endif
	}*/
	///////////////////////////// SQueue - Lock free queue - CECD /////////////////////////////////
	printf("SQueue - Concurrent Enqueue Concurrent Dequeue\n");

	enqueuetimestamp = (ticks *)malloc(sizeof(ticks)*NUM_SAMPLES);
	dequeuetimestamp = (ticks *)malloc(sizeof(ticks)*NUM_SAMPLES);

	for (int i=0;i<NUM_SAMPLES;i++)
	{
		enqueuetimestamp[i] = (ticks)0;
		dequeuetimestamp[i] = (ticks)0;
	}

	FILE *fp=fopen("data.txt", "w");
	//FILE *dfp=fopen("dequeuedata.txt", "w");
	if(fp == NULL)
		exit(-1);
	printf("Type,Operation,NumSamples,CycleCount,NumThreads\n");
	for (int k = 1; k <= NUM_THREADS; k = k * 2) {

		fprintf(fp,"Num threads - %d, Num Samples - %d, Num CPUs - %d \n", CUR_NUM_THREADS,NUM_SAMPLES, NUM_CPUS);
		printf("Num threads - %d, Num Samples - %d, Num CPUs - %d \n", CUR_NUM_THREADS,NUM_SAMPLES, NUM_CPUS);

		InitQueue();
		ResetCounters();
		//if(k == 16) k=12;
		CUR_NUM_THREADS = k;

		pthread_t *worker_threads;
		pthread_t *enqueue_threads;

		worker_threads = (pthread_t *) malloc(
				sizeof(pthread_t) * CUR_NUM_THREADS);
		enqueue_threads = (pthread_t *) malloc(
				sizeof(pthread_t) * CUR_NUM_THREADS);

		cpu_set_t set;

		CPU_ZERO(&set);
		CPU_SET(0, &set);

		pthread_setaffinity_np(pthread_self(), sizeof(set), &set);

#ifndef WAITFORENQUEUE
		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&worker_threads[i], NULL, worker_handler,
					(void*) (unsigned long) (i));
#endif

		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&enqueue_threads[i], NULL, enqueue_handler,
					(void*) (unsigned long) (i));

		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_join(enqueue_threads[i], NULL);

#ifdef WAITFORENQUEUE
		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&worker_threads[i], NULL, worker_handler, (void*)(unsigned long)(i));
#endif
		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_join(worker_threads[i], NULL);

		for(int i=0;i<NUM_SAMPLES;i++)
		{
			fprintf(fp, "%ld %ld\n", enqueuetimestamp[i], dequeuetimestamp[i]);
		}
		//printf("squeue_cecd,enqueue,%d,%ld,%d\n", NUM_SAMPLES,
				//enqueue_ticks / NUM_SAMPLES, CUR_NUM_THREADS);
		//printf("squeue_cecd,dequeue,%d,%ld,%d\n", NUM_SAMPLES,
				//dequeue_ticks / NUM_SAMPLES, CUR_NUM_THREADS);
	printf("numbers %d, %d\n", numEnqueue, numDequeue);

	ticks totalEnqueueTicks = 0,  totalDequeueTicks = 0;
	ticks enqueuetickMin = enqueuetimestamp[0];
	ticks enqueuetickMax = enqueuetimestamp[0];
	ticks dequeuetickMin = dequeuetimestamp[0];
	ticks dequeuetickMax = dequeuetimestamp[0];
	ticks *numEnqueueTicks, *numDequeueTicks;
	   numEnqueueTicks = (ticks *)malloc(sizeof(ticks)*NUM_SAMPLES);
	   numDequeueTicks = (ticks *)malloc(sizeof(ticks)*NUM_SAMPLES);

	//compute the elapsed time per invocation, and find min and max
	for (int i=0;i<NUM_SAMPLES-1;i++)
	{
		//compute the elapsed time per invocation, and subtract the cost of the emtpy loop cost per iteration
		numEnqueueTicks[i]=enqueuetimestamp[i];

		totalEnqueueTicks += numEnqueueTicks[i];
		if (numEnqueueTicks[i]>enqueuetickMax) enqueuetickMax = numEnqueueTicks[i];
		if (numEnqueueTicks[i]<enqueuetickMin) enqueuetickMin = numEnqueueTicks[i];

		numDequeueTicks[i]= dequeuetimestamp[i];

		totalDequeueTicks += numDequeueTicks[i];
		if (numDequeueTicks[i]>dequeuetickMax) dequeuetickMax = numDequeueTicks[i];
		if (numDequeueTicks[i]<dequeuetickMin) dequeuetickMin = numDequeueTicks[i];
	}
	//fclose(fp);
	//compute average
	double tickEnqueueAverage = (totalEnqueueTicks/(NUM_SAMPLES));
	double tickDequeueAverage = (totalDequeueTicks/(NUM_SAMPLES));

	//print summary statistics
	//printf("Loop-cycles: %llu\n",end_tick-start_tick);
	//if (NUM_THREADS == 0)
	//{
		printf("Enqueue Min: %ld\n", enqueuetickMin);
		printf("Dequeue Min: %ld\n", dequeuetickMin);

		printf("Enqueue Max: %ld\n", enqueuetickMax);
		printf("Dequeue Max: %ld\n", dequeuetickMax);

		printf("Average Enqueue : %lf\n", tickEnqueueAverage);
		printf("Average Dequeue : %lf\n", tickDequeueAverage);

	//}
	}
	fclose(fp);
		printf("Done!!\n");
	///////////////////////////// CK - Lock free queue - SPMC /////////////////////////////////
	/*printf("\nCK - Single Producer Multiple Consumer \n");
	printf("Type,Operation,NumSamples,CycleCount,NumThreads\n");
	struct entry entry = { 0, 0 };
	ck_ring_buffer_t *buf;
	ck_ring_t ring;

	size = 8; //Hardcoded for benchmarking purposes

	buf = malloc(sizeof(ck_ring_buffer_t) * size);

	ck_ring_init(&ring, size);

	for (int k = 1; k <= NUM_THREADS; k = k * 2) {
		ResetCounters();
		CUR_NUM_THREADS = k;
		pthread_t *worker_threads;

		worker_threads = (pthread_t *) malloc(
				sizeof(pthread_t) * CUR_NUM_THREADS);

		struct arg_struct args;
		args.ring = ring;
		args.buf = buf;
#ifndef WAITFORENQUEUE
		for (int i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&worker_threads[i], NULL, ck_worker_handler,(void *) &args);
#endif
		e_a = d_a = s = e = 0;
		for (r = 0; r < NUM_SAMPLES; r++)
		{
			s = getticks();
			ck_ring_enqueue_spmc(&ring, buf, &entry);
			e = getticks();
			e_a += (e - s);
		}
#ifdef WAITFORENQUEUE
		for (int i = 0; i < CUR_NUM_THREADS; i++)
			pthread_create(&worker_threads[i], NULL, ck_worker_handler,(void *) &args);
#endif

		for (i = 0; i < CUR_NUM_THREADS; i++)
			pthread_join(worker_threads[i], NULL);

		printf("ck_spmc,enqueue,%d,%" PRIu64 ",%d\n", NUM_SAMPLES, e_a/NUM_SAMPLES, CUR_NUM_THREADS);
		printf("ck_spmc,dequeue,%d,%" PRIu64 ",%d\n", NUM_SAMPLES, dequeue_ticks/CUR_NUM_THREADS, CUR_NUM_THREADS);
	}
	printf("\nBasic - Single Producer Multiple Consumer \n");
	for (k=1;k<=NUM_THREADS;k=k*2)
		{
			ResetCounters();
			InitBasicQueue();
			CUR_NUM_THREADS = k;
			ticks start_tick,end_tick,diff_tick;
			pthread_t *worker_threads;

			worker_threads = (pthread_t *) malloc(sizeof(pthread_t) * NUM_THREADS);
#ifndef WAITFORENQUEUE
			for (i = 0; i < CUR_NUM_THREADS; i++)
							pthread_create(&worker_threads[i], NULL, basicworker_handler, NULL);
#endif
			//gettimeofday(&sTime, NULL);
			//double startSeconds = sTime.tv_sec + ((double)sTime.tv_usec)/1000000.0;
			start_tick = getticks();
			for (i=0;i<NUM_SAMPLES;i++)
			{
				//start_tick = getticks();
				BasicEnqueue((i+1));
				//end_tick = getticks();

			}
			end_tick = getticks();
			//gettimeofday(&eTime, NULL);
			//double endSeconds = eTime.tv_sec + ((double)eTime.tv_usec)/1000000.0;

#ifdef WAITFORENQUEUE
			for (i = 0; i < CUR_NUM_THREADS; i++)
				pthread_create(&worker_threads[i], NULL, basicworker_handler, NULL);
#endif
			diff_tick = end_tick - start_tick;

			for (int i = 0; i < CUR_NUM_THREADS; i++)
				pthread_join(worker_threads[i], NULL);

			//double diffSeconds = endSeconds - startSeconds;

			printf("Type,Operation,NumSamples,CycleCount,TimeElapsed,NumThreads\n");
			printf("basic,enqueue,%d,%ld,%d\n", NUM_SAMPLES, diff_tick/NUM_SAMPLES, NUM_THREADS);

			printf("basic,dequeue,%d,%ld,%d\n", NUM_SAMPLES, dequeue_ticks/NUM_SAMPLES, NUM_THREADS);
		}*/
	return 0;
}
